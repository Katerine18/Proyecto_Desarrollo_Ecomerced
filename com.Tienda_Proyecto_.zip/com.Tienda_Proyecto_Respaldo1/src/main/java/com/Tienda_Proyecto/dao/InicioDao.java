
package com.Tienda_Proyecto.dao;

import com.Tienda_Proyecto.domain.Inicio;
import org.springframework.data.jpa.repository.JpaRepository;
public interface InicioDao extends JpaRepository<Inicio,Long> {
    
}

